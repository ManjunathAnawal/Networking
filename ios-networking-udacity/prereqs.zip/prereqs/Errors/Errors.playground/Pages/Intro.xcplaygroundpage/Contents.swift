//: # Errors
//: Errors, or error handling, gives developers the ability to safely execute error-prone code.
//:
//: [Next](@next)
