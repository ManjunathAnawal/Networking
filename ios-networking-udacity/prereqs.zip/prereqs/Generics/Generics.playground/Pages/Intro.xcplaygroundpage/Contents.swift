//: # Generics
//: Generics gives developers the ability to specify functionality that can be applied to any type or specific types like those that implement a certain protocol.
//:
//: [Next](@next)
