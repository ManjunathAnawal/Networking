import Foundation
var text = "batball"
let searchString = text.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)
print(searchString)
