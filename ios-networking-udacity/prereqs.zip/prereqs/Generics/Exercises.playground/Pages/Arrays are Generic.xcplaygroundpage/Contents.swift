//: [Previous](@previous)
//: ### Arrays are Generic
//: - Callout(Exercise):
//: Create an array of bools called `boolArray` that uses the longhand initialization syntax for its generic parameter.
//:

//: [Next](@next)
