//: # Errors: Exercises Solutions
//: The following pages contain solutions for the errors exercises.
//:
//: [Next](@next)
