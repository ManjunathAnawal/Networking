//: [Previous](@previous)
//: ### Guard Versus If
//: There are no exercises for this section, please click **Next** to continue.

//: [Next](@next)
