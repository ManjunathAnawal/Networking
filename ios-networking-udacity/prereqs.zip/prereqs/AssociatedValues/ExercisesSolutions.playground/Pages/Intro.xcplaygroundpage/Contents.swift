//: # Associated Values: Exercises Solutions
//: The following pages contain solutions for the associated values exercises.
//:
//: [Next](@next)
