//: # Guards: Exercises Solutions
//: The following pages contain solutions for the guards exercises.
//:
//: [Next](@next)

