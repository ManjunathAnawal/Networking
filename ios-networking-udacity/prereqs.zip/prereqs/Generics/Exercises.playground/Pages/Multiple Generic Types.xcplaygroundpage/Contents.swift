//: [Previous](@previous)
//: ### Multiple Generic Types
//: There are no exercises for this section.
