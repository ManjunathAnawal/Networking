//: # Associated Values: Exercises
//: The following pages contain exercises for associated values.
//:
//: [Next](@next)
