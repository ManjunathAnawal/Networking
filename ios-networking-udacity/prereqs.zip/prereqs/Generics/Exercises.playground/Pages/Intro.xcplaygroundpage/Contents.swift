//: # Generics: Exercises
//: The following pages contain exercises for generics.
//:
//: [Next](@next)

