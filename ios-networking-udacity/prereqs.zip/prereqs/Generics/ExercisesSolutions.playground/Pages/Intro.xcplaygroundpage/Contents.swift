//: # Generics: Exercises Solutions
//: The following pages contain solutions for the generics exercises.
//:
//: [Next](@next)
